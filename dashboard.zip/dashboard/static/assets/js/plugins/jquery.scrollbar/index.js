require('./jquery.scrollbar');
module.exports = 'jQueryScrollbar';