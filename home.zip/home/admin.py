from django.contrib import admin
from .models import(contact_details)
# Register your models here.

admin.site.register(contact_details)