from django.apps import AppConfig


class HomeblogConfig(AppConfig):
    name = 'homeblog'
